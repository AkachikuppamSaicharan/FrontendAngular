export  interface CustomerDetails{
    name:string;
    userID:string;
    address:string;
    customerType:string;
    email:string;
    mobile:number;
}